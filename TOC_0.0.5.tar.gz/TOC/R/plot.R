# Author: Ali Santacruz Yunzhe Zhu
# Date :  December 2019
# Version 1.2
# Licence GPL v3


if (!isGeneric("plot")) {
	setGeneric("plot", function(x, ...)
		standardGeneric("plot"))
}

setMethod("plot", signature='Roc',
          definition = function(x, labelThres=FALSE, modelLeg="Model", digits=3, nticks=5, digitsL=1, posL = NULL, offsetL = 0.5, addAUC = TRUE, digitsAUC=2, ...)  {
            .plotROC(x, labelThres=labelThres, modelLeg=modelLeg, digits=digits, nticks=nticks, digitsL=digitsL, posL = posL, offsetL = offsetL, addAUC = addAUC, digitsAUC=digitsAUC,  ...)
            return(invisible(NULL))
          }
)

setMethod("plot", signature='list',
          definition = function(x, labelThres=FALSE, modelLeg="Model", digits=3, nticks=5, digitsL=1, posL = NULL, offsetL = 0.5, addAUC = TRUE, digitsAUC=2, addCC = FALSE, ...)  {
            .plots(x, labelThres=labelThres, modelLeg=modelLeg, digits=digits, nticks=nticks, digitsL=digitsL, posL = posL, offsetL = offsetL, addAUC = addAUC, digitsAUC=digitsAUC, addCC = addCC, ...)
            return(invisible(NULL))
          }
)

setMethod("plot", signature ='Toc',
          definition = function(x, labelThres=FALSE, modelLeg="Model", digits=3, nticks=5, digitsL=1, posL = NULL, offsetL = 0.5, addAUC = TRUE, digitsAUC=2, addCC = FALSE, ...)  {
            .plotTOC(x, labelThres=labelThres, modelLeg=modelLeg, digits=digits, nticks=nticks, digitsL=digitsL, posL = posL, offsetL = offsetL, addAUC = addAUC, digitsAUC=digitsAUC, addCC = addCC, ...)
            return(invisible(NULL))
          }
)
